-- Generated with Durty Cloth Tool v3.1.0.3 (https://gta.clothing)

fx_version 'cerulean'
game { 'gta5' }

author 'blue'
files {
  'mp_m_freemode_01_mp_m_bs_bdbmale_shop.meta'
}

data_file 'SHOP_PED_APPAREL_META_FILE' 'mp_m_freemode_01_mp_m_bs_bdbmale_shop.meta'